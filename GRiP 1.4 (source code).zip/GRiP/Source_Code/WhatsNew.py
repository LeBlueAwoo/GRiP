import os
os.system("color A0")
file=open(r"Documentation/01-Whats_New.txt","r")
contents=file.read()
print(contents)
leave=input("\n\n\n\n\n############\nScroll to the top to see it all or press ENTER to close...\n############")


