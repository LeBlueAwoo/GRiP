import os
import keyboard
import time
while True:
    print("Press Q to exit")
    if keyboard.is_pressed('q'):
        print('Exiting...')
        time.sleep(0.1)
        break
    os.system("color 0F")
    os.system("color 90")
    os.system("color 2F")
    os.system("color B0")
    os.system("color 4F")
    os.system("color D0")
    os.system("cls")
