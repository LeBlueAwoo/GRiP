import getpass
import sys
import time

with open("pw.txt", "rt") as pword:
    password=pword.read()

def passw():
    tries=int("5")
    while True:
        if tries==int("0"):
            input("Password incorrect! You have no tries left!\nPress ENTER to exit...")
            sys.exit()
        else:
            pword=getpass.getpass("Password: ")
            if pword==password:
                print("Hello, user!\nTo change the password, edit pwstore.py.\nUnlocking...")
                time.sleep(2)
                break
            else:
                tries=(tries-1)
                if tries==4:
                    print(str("Password incorrect! You have 4 tries left.\nTip: This password is case sensitive!"))
                elif tries==3:
                    print(str("Password incorrect! You have 3 tries left.\nTip: Brute force will get you nowhere!"))
                elif tries==2:
                    print(str("Password incorrect! You have 2 tries left.\nTip: No, seriously, this is getting ridiculous!"))
                elif tries==1:
                    print(str("Password incorrect! You have 1 try left.\nTip: Quit it!"))

#For password protection, remove the # from the beginning of the line below
#passw()
########################
GUI=input("Do you want to start GRiP with a GUI? (y/n) ")
if GUI==("y"):
    import GRIP_grip.py
if GUI==("n"):
    import TRiP_grip.py
