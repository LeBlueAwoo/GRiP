with open("password.txt", "r") as in_password:
    password = in_password.read()

openFile=input("Please enter the GRiP password again: ")
if openFile == password:
    print("Acess Granted")
    passwordChange = input("Change password? (yes/no) ")

    if passwordChange == "yes":
        in_password = open("password.txt", "w")
        in_password.close()
        newPassword=input("Enter new password: ")
        in_password = open("password.txt", "w")
        in_password.write(newPassword)
        in_password.close()
