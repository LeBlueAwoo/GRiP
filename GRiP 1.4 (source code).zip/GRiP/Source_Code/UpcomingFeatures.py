import os
os.system("color 90")
file=open(r"Documentation/02-Upcoming_Features.txt","r")
contents=file.read()
print(contents)
leave=input("\n\n\n\n\n############\nScroll to the top to see it all or press ENTER to close...\n############")

