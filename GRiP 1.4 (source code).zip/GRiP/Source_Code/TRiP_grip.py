print("\n\nImporting modules...\n###################")
module=("null")
try:
    module=("traceback")
    import traceback
    module=("datetime")
    import datetime
    module=("time")
    import time
    module=("os")
    import os
    module=("sys")
    import sys
    module=("string")
    import string
    module=("keyboard")
    import keyboard
    module=("assets from tkinter")
    from tkinter import *
    print("Done!")
except:
    if module==("null"):
        while True:
            print("An unknown error occured preventing any modules from loading. PPPP cannot run without modules!")
            input("Please close this window and find what is causing this.")
    else:
        print("Error while importing " + module + "! The file could not be loaded, as it cannot be found or does not exist. Here is some more information:\n")
        traceback.print_exc()
        print("\nYou can try to run PPPP without the module, but you are likely to run into problems when it is needed, so it is strongly recommended\nthat you exit this program and try to fix it, if possible.")
        sansmod=input("Continue without " + module + "? (y/n)").lower()
        if sansmod==("n"):
            sys.exit()
go=input("This program involves extensive use of the \'os.system\' command, so the program may not work properly without access to system commands.\nThis program was designed to be used on Windows/DOS so if used on OSX or Linux, certain features may be missing or unuseable.\nPress ENTER to continue...")   
while True:
    os.system("clear")
    os.system("cls")
    os.system("color B0")
    print("┌────────────────────────────────────────┐")
    print("│        Select a program to run:        │")
    print("├────────────────────────────────────────┤")
    print("│1.                Lag                   │")
    print("│2.             PyTerminal               │")
    print("│3.               Evolve                 │")
    print("│4.          Can't touch this!           │")
    print("│5.               Clock                  │")
    print("├────────────────────────────────────────┤")
    print("│0.               Quit...                │")
    print("└────────────────────────────────────────┘")
    menu=("")
    menu=int(input("Program to run (0-5): "))
    if menu==1:
        os.system("clear")
        os.system("cls")
        os.system("color 4B")
        go=input("WARNING: This program has the potential to crash a computer if run for any length of time!\nRemember: you can stop the lag loop at any time by clicking on the main window and\nrepeatedly pressing Q\nContinue? (y/n) ").lower()
        if go==("n"):
                continue
        else:
            os.system("color 1F")
            print("Press Q to quit...")
            while True:
                os.startfile("cmd.exe")
                if keyboard.is_pressed('q'):
                    print('Exiting...')
                    time.sleep(0.5)
                    break
                else:
                    pass
                    time.sleep(0.5)
    if menu==2:
        try:
            os.system("clear")
            os.system("cls")
            os.system("color 0A")
            print("#### Python Terminal Emulator 1.6.1 ####\n\nThis program can allow access to Windows commands\nbut will not work if CMD.exe has been blocked or deleted!\n\nTo leave, type \'exit\'.\nTo change to another folder, enter \'cd\'.")
            while True:
                print("\n")
                cwd=os.getcwd()
                command=input(cwd + "> ")
                if command==("cd"):
                    try:
                        cd=input("New directory: ")
                        os.chdir(cd)
                    except:
                        print("This directory does not exist.")
                if command==("exit"):
                    print("Please wait...")
                    time.sleep(0.1)
                    break    
                else:
                    os.system(command)
        except Exception as ex:
            os.system("clear")
            os.system("cls")
            os.system("color 0C")
            print("WARNING: Module \'pytermemu\' has encountered the following error:\n")
            traceback.print_exc()
            input("\nPress ENTER to close the program.\n")
            sys.exit()
    if menu==3:
        import random
        os.system("clear")
        os.system("cls")
        os.system("color 2F")
        try:
            possibleCharacters = string.ascii_lowercase + string.digits + string.ascii_uppercase + ' !£$%^&*()\"\\`¬-=_+[]{};\'#:@~,./<>?'
            target = input("Enter your target text: ")
            attemptThis = ''.join(random.choice(possibleCharacters) for i in range(len(target)))
            attemptNext = ''
            completed = False
            generation = 0
            while completed == False:
                print(attemptThis)
                attemptNext = ''
                completed = True
                for i in range(len(target)):
                    if attemptThis[i] != target[i]:
                        completed = False
                        attemptNext += random.choice(possibleCharacters)
                    else:
                        attemptNext += target[i]
                generation += 1
                attemptThis = attemptNext
                time.sleep(0.1)
            print("Target matched! That took " + str(generation) + " generations")
            input("Press ENTER to continue...")
        except Exception as ex:
            os.system("clear")
            os.system("cls")
            os.system("color 0C")
            print("WARNING: Module \'evolve\' has encountered the following error:\n")
            traceback.print_exc()
            input("\nPress ENTER to close the program.\n")
    if menu==4:
        try:
            from random import *
            os.system("clear")
            os.system("cls")
            def do_event(event):
                print("{},{}".format(event.x,event.y))
            def jump(event):
                app.hello_b.place(relx=random(),rely=random())
            class App:
                def __init__(self,master):
                    frame = Frame(master)
                    master.geometry("500x500")
                    master.title("Can't Touch This!")
                    master.bind("<Button-1>",do_event)
                    master.bind("<Button-1>",do_event)
                    frame.pack()
                    self.hello_b = Button(master,text="Quit",command=sys.exit)
                    self.hello_b.bind("<Enter>",jump)
                    self.hello_b.pack()
            root = Tk()
            app = App(root)
            root.mainloop()          
        except Exception as ex:
            os.system("clear")
            os.system("cls")
            os.system("color 0C")
            print("WARNING: Module \'canttouchthis\' has encountered the following error:\n")
            traceback.print_exc()
            input("\nPress ENTER to close the program.\n")
    if menu==5:
        while True:
            os.system("clear")
            os.system("cls")
            print(datetime.datetime.now().strftime("Date: %d-%m-%Y \n\nTime: %H:%M:%S\n\n\n\n\nPress Q to exit..."))
            time.sleep(0.1)
            try:
                if keyboard.is_pressed('q'):
                    print('Exiting...')
                    time.sleep(1)
                    break
                else:
                    pass
            except:
                print(" ")
    if menu==0:
        leave=input("Are you sure? (y/n)").lower()
        if leave==("y"):
            os.system("clear")
            os.system("cls")
            sys.exit()
        else:
            pass
    else:
        print("Please enter a number from 0-5.")
print("Bye!")
