#########################################################################
#########################################################################
##                                                                     ##
##    This is the python code that runs GRiP... all 383 lines of it!   ##
##     GRiP is only one of many files that make up this program as     ##
##   a whole, but it's all organised, ready to be read (if you have    ##
##                 383 lines worth of spare time...!)                  ##
##                                                                     ##
##    To see how it all works, just look out for red text like this    ##
##                                                                     ##
##                        -Max Nicholson-                              ##
##          The guy who has a little too much spare time               ##
##                                                                     ##
#########################################################################
#########################################################################

ver=("Early access BETA 1.4") # <- The version number

print("Starting GRiP", ver)

#External scripts used by GRiP and its subprograms are loaded here
print("Loading modules...")
try:
    module=("null")

    module=("keyboard")                        #Detects keyboard input
    import keyboard
    
    module=("time")                            #Gets the time from the OS
    import time
    
    module=("sys")                             #Allows GRIP to alter the state of the Python executable and read data about Python and the operating system being used
    import sys
    
    module=("traceback")                       #Shows an error instead of just crashing the program
    import traceback
    
    module=("os")                              #Allows GRiP access to system commands
    import os
    
    module=("tkinter")                         #Draws the graphics used in the menu and some subprograms
    import tkinter
    
    module=("messagebox")                      #Lets tkinter create message dialogues
    import tkinter.messagebox
    
    module=("random")                          #Generates random characters, numbers or whatever you need it to
    import random
    
    module=("string")                          #Utilities for processing strings of characters
    import string
    
    module=("datetime")                        #Allows expression of the date and time
    import datetime
    
    module=("tkinter as an internal asset")    #Exposes tkinter's internal functions to the Python interpreter, allowing them to be called without typing tkinter.___ in front
    from tkinter import *
    
    module=("random as an internal asset")     #Same as "tkinter as an internal asset"
    from random import *
    
    time.sleep(1.1)
    print("Loaded 11 modules!")

except:
    install=("Fail")
    #Error handling for module initialisation
    if module==("null"):
        while True:
            print("An unknown error occured preventing the modules from loading. GRiP cannot run without modules!")
            input("Please close this window and find what is causing this.")
            
    else:
        #Attempts to install the missing module then restarts GRiP if successful
        print("Missing module: " + module + ". Attempting to install it...")
        try:
            os.system("pip install " + module)
            install=("Done")
            time.sleep(1)
            os.system("py GRIP_grip.py")
            sys.exit
        except:
            print("Install unsuccessful")
        
        #Shows which module failed (if any) and gives the user the option to continue without it (doing this will break some features, as all of these modules are used by AT LEAST 1 program and "os" is used in all of them)
        if install==("Fail"):
            print("Error while installing " + module + "!\nThe file could not be loaded, as it cannot be found or does not exist. Here is some more information:\n")
            traceback.print_exc()
            sansmod=input("Continue without " + module + "? (y/n)").lower()
        
            if sansmod==("n"):
                print("Writing error to log...")
                sys.stdout = open('GRIP.log', 'w')
                traceback.print_exc()
                sys.exit()

#Do this every time a GRiP app is closed
def home():
    os.system("cls")
    os.system("color 07")
    print("Don't close this window! GRiP apps run here.")

print("Setting up GRiP apps...")
#Subprograms are defined here
try:
    #LAG v1.4 - A program used for torturing your CPU by continuously opening command prompts until Windows freezes! Next to no practical purpose
    def lag():
        os.system("cls")
        os.system("color 4B")
        go=input("WARNING: This program has the potential to crash a computer if run for any length of time!\nRemember: you can stop the lag loop at any time by clicking on the main window and\nrepeatedly pressing SPACE.\nContinue? (y/n) ").lower()

        if go==("n"):
            print("")
        else:
            os.system("color 1F")
            print("Press SPACE to quit...")
            #Enter the time between windows opening. Leaving this blank sets it to 0.5 seconds
            delay=input("Enter the delay between windows opening in seconds (Default: 0.5)")
            
            if delay==(""):
                delay=("0.5")
                
            while True:
            #Keep opening command prompts until either the space key is pressed or the system crashes, which ever happens first
                os.startfile("cmd.exe")
                
                if keyboard.is_pressed(' '):
                    print('Exiting...')
                    time.sleep(delay)
                    break
                
                else:
                    pass
                    time.sleep(delay)

        home()
                    
    def men2():
        #PyTerm v1.7.0 - Alternative interface for Windows' built-in command prompt
        os.system("clear")
        os.system("cls")
        os.system("color 0A")
        print("#### Python Terminal Emulator 1.7.0 ####\n\nNOTE: This will not work if CMD.exe has been blocked or deleted!\n\nTo leave, type \'exit\'.")

        while True:
            #Get current folder
            print("\n")
            cwd=os.getcwd()
            command=input(cwd + "> ")
            #Change to specified folder (if it exists)
            if "cd" in command:
                try:
                    cd=command.split()
                    os.chdir(cd[1])
                except:
                    print(cd[1], "was not found here. Try mkdir", cd[1])
                    
            if command==("exit"):
            #If "exit" is entered, exit the terminal
                print("Please wait...")
                time.sleep(0.1)
                break    
            else:
                os.system(command)

        home()
        
    def men3():
        #Evolve v1.0 - Type something in and watch as a string of randomly generated characters morphs into what you typed in
        possibleCharacters = string.ascii_lowercase + string.digits + string.ascii_uppercase + ' !£$%^&*()\"\\`¬-=_+[]{};\'#:@~,./<>?'
        target = input("Enter your target text: ")
        attemptThis = ''.join(random.choice(possibleCharacters) for i in range(len(target)))
        attemptNext = ''
        completed = False
        generation = 0
        
        #Keep cycling through characters until it matches the one in the string you entered
        while completed == False:
            print(attemptThis)
            attemptNext = ''
            completed = True
            
            for i in range(len(target)):
                if attemptThis[i] != target[i]:
                    completed = False
                    attemptNext += random.choice(possibleCharacters)
                    
                else:
                    attemptNext += target[i]
                    
            generation += 1
            attemptThis = attemptNext
            time.sleep(0.1)
        #When finished, show how many combinations Evolve went through to create your string
        input("Target matched! That took " + str(generation) + " generations!\nPress ENTER to continue...")

        home()
        
    def men4():
        #Can't Touch This v1.0 - Really... you can't!
        def do_event(event):
            print("{},{}".format(event.x,event.y))
            
        def jump(event):
            app.hello_b.place(relx=random(),rely=random())
            
        class App:
            def __init__(self,master):
                frame = Frame(master)
                master.geometry("500x500")
                master.title("Can't Touch This!")
                master.bind("<Button-1>",do_event)
                master.bind("<Button-1>",do_event)
                frame.pack()
                self.hello_b = Button(master,text="Quit",command=sys.exit)
                self.hello_b.bind("<Enter>",jump)
                self.hello_b.pack()
                
        root = Tk()
        app = App(root)
        root.mainloop()

        home()

    def men5():
        #Clock v1.1 - It's a clock...
        while True:
            os.system("cls")
            os.system("color 0F")
            print(datetime.datetime.now().strftime("Date: %d-%m-%Y \n\nTime: %H:%M:%S\n\n\n\n\nPress Q to exit..."))
            time.sleep(1)
            #Close the clock if Q is pressed
            try:
                if keyboard.is_pressed('q'):
                    print('Exiting...')
                    time.sleep(0.1)
                    break
                
                else:
                    pass
                
            except:
                continue
            
        
        home()

    def trip():
        import trip.py
        home()

    def calculator():
        #calculator v1.0
        os.system("cls")
        os.system("color 0B")
        print("Calculator v1.0\nType exit to close")
        stop=("False")
        while stop==("False"):
            string=input("\n> ")

        #Define operations
            try:
                #Add
                if "+" in string:
                    plus=string.find("+")
                    num2=string[(plus + 1) :]
                    num1=string[: plus]
                    numSum=(int(num1) + int(num2))
                    print(str(num1) + " + " + str(num2) + " = " + str(numSum))

                #Subtract
                if "-" in string:
                    sub=string.find("-")
                    num2=string[(sub + 1) :]
                    num1=string[: sub]
                    numSum=(int(num1) - int(num2))
                    print(str(num1) + " - " + str(num2) + " = " + str(numSum))

                #Multiply
                if "*" in string:
                    mul=string.find("*")
                    num2=string[(mul + 1) :]
                    num1=string[: mul]
                    numSum=(int(num1) * int(num2))
                    print(str(num1) + " * " + str(num2) + " = " + str(numSum))

                #Divide
                if "/" in string:
                    div=string.find("/")
                    num2=string[(div + 1) :]
                    num1=string[: div]
                    numSum=(int(num1) / int(num2))
                    print(str(num1) + " / " + str(num2) + " = " + str(numSum))
            except:
                print("Calculator 1.0 only accepts numbers containing integer values from 1 to 9 and only 1 operation at a time.\nTry doing each step one at a time.")
            
            #If "exit" is entered, exit the program
            if "exit" in string:
                stop=("True")
                home()

except:
    #Error handling for this section
    print("Writing error to log...")
    sys.stdout = open('GRIP.log', 'w')
    traceback.print_exc()


    
print("Done")
time.sleep(1)
os.system("cls")
#Clear the screen ready to load the programs
print("Don't close this window! GRiP apps run here.")

try:
    #Draw the main menu GUI
    Top=tkinter.Tk()
    title=("Graphical Randomness In Python", ver)
    Top.title(title)
    C=tkinter.Canvas(Top, bd=1, bg="cyan", width=1000, height=200)                                #<- Set colour and size of the menu window
    C.pack()
    C.create_text(500,90,fill="darkblue",font="verdana 30 bold",text="Welcome to GRIP!")                #<- Title
    C.create_text(500,140,fill="darkblue",font="verdana 10",text="Graphical Randomness in Python")      #<- Name
    C.create_text(90,15,fill="darkblue",font="verdana 10",text=ver)                                     #<- Version no.
    label = Label(Top, text= "Select an app here...")

    # create the main sections of the layout, 
    # and lay them out
    top = tkinter.Frame(Top)
    bottom = tkinter.Frame(Top)
    top.pack(side="top")
    bottom.pack(expand=True)

    #Make the buttons... (The above programs are only run when these buttons are pressed)
    bA=tkinter.Button(top, text="Lag", command=lag, width=19, height=2)
    bB=tkinter.Button(top, text="PyTerminal", command=men2, width=19, height=2 )
    bC=tkinter.Button(top, text="Evolve", command=men3,width=19, height=2 )
    bD=tkinter.Button(top, text="Can't touch this!", command=men4, width=19, height=2 )
    bE=tkinter.Button(top, text="Clock", command=men5,width=19, height=2 )
    bJ=tkinter.Button(top, text="Calculator", command=calculator,width=19, height=2 )

    #...and place them all at the bottom of the window
    label.pack(side=("left")) 
    bA.pack(in_=top, side="left")
    bB.pack(in_=top, side="left")
    bC.pack(in_=top, side="left")
    bD.pack(in_=top, side="left")
    bE.pack(in_=top, side="left")
    bJ.pack(in_=top, side="left")

    #Link your own programs or scripts in these buttons...
    bF=tkinter.Button(top, text="Seizure Button", command=trip,width=19, height=2)    #Hmm... wonder what this does?#
    #bG=tkinter.Button(top, text="My Program or script name here", command=<Command_to_open_file>,width=19, height=2 )
    #bH=tkinter.Button(top, text="My Program or script name here", command=<Command_to_open_file>,width=19, height=2 )
    #bI=tkinter.Button(top, text="My Program or script name here", command=<Command_to_open_file>,width=19, height=2 )
    
    #...and uncomment these to enable them!
    #bF.pack(in_=top, side="left") #
    #bG.pack(in_=top, side="left")
    #bH.pack(in_=top, side="left")
    #bI.pack(in_=top, side="left")

    
    #If this button is pressed, GRiP closes
    bZ=tkinter.Button(top, text="Exit", command=Top.destroy, width=19, height=2)

    bZ.pack(in_=top, side="left")
	

    top.mainloop()
    
except:
    #If the launcher can't be launched, launch another launcher... and write to the log file
    print("Error starting the launcher\nWriting error to log...\n")
    time.sleep(1)
    print("Restarting in text mode... Here's what failed:")
    sys.stdout = open('GRIP.log', 'w')
    traceback.print_exc()
    #Starts the fallback launcher and exits
    os.system("python TRiP_grip.py")
    sys.exit()
	#main.py, the script that decides whether or not to load the GUI treats GRiP.py and TRiP.py as modules, so when they exit,
	#sys.exit must be used, as this closes the entire process, instead of just this script.
