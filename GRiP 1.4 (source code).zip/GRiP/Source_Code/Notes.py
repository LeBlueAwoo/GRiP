import os
os.system("color E0")
file=open(r"Documentation/04-Notes.txt","r")
contents=file.read()
print(contents)
leave=input("\n\n\n\n\n############\nScroll to the top to see it all or press ENTER to close...\n############")

