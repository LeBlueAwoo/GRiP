import sys
import os
import tkinter
from tkinter import *

os.system("cls")

def man():
    os.system("py Manual.py")

def UF():
    os.system("py UpcomingFeatures.py")

def new():
    os.system("py WhatsNew.py")

def notes():
    os.system("py Notes.py")
    
#Draw the main menu GUI
Top=tkinter.Tk()

Top.title("Documentation Station")
C=tkinter.Canvas(Top, bd=1, bg="light grey", width=1000, height=200)
C.pack()
C.create_text(500,90,fill="darkblue",font="verdana 30 bold",text="GRiP Documentation")

# create the main sections of the layout, 
# and lay them out
top = tkinter.Frame(Top)
bottom = tkinter.Frame(Top)
top.pack(side="top")
bottom.pack(expand=True)

#Make the buttons... (The above programs are only run when these buttons are pressed)
bA=tkinter.Button(top, text="Manual", command=man, width=19, height=2)
bB=tkinter.Button(top, text="Upcoming Features", command=UF, width=19, height=2 )
bC=tkinter.Button(top, text="What's New?", command=new,width=19, height=2 )
bD=tkinter.Button(top, text="Release Notes", command=notes, width=19, height=2 )

#...and place them all at the bottom of the window
bA.pack(in_=top, side="left")
bB.pack(in_=top, side="left")
bC.pack(in_=top, side="left")
bD.pack(in_=top, side="left")

top.mainloop()
